package app;

public class TicTacToe{
		
	private TicTacToeController controller;
	private Board board;
	private char playerTurn = 'X';
	private boolean hasWon = false;
	
	public TicTacToe(TicTacToeController controller) {
		this.controller = controller;
		board = new Board();
		controller.updatePlayerTurn(playerTurn);
		controller.updateBoard(board.getBoard());
	}
	
	
	void play(int x, int y) {
		if (board.isLegal(x, y) && !hasWon) {
			board.doMove(x, y, playerTurn);
			controller.updateBoard(board.getBoard());
			if (board.checkForWin(playerTurn)) {
				hasWon = true;
				controller.setResult("Player " + playerTurn + " has won!");
			}
			
			if (!hasWon && board.isFull()) {
				hasWon = true;
				controller.setResult("The game is a tie!");
			}
			
			switch (playerTurn) {
			case 'X':
				playerTurn = 'O';
				break;
			default:
				playerTurn = 'X';
			}
			controller.updatePlayerTurn(playerTurn);
		}
	}
}
