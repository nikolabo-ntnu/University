package app;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;

public class TicTacToeController {
	
	// Non-FXML variables
	private TicTacToe game;
	private ObservableList<Node> buttons;
	
	// FXML variables
    @FXML
    private GridPane grid;
    @FXML
    private Label turnField;
    @FXML
    private Label playerWin;

    
    @FXML
    public void initialize() {
    	buttons = grid.getChildren();
    	game = new TicTacToe(this);
	}
    
    @FXML
    void onClick(ActionEvent event) {
    	Button button = (Button) event.getSource();
    	int x = nullConverter(GridPane.getRowIndex(button));
    	int y = nullConverter(GridPane.getColumnIndex(button));
    	
    	game.play(x, y);
    }
    
    @FXML
    void restartGame(ActionEvent event) {
    	game = new TicTacToe(this);
    	playerWin.setText("");
    }
    
    // Since GridPane.getRowIndex(button) returns null for 0.
    int nullConverter(Integer x) {
    	if (x == null) {
    		return 0;
    	}
    	else {
    		return x;
    	}
    }
    
    void updateBoard(char[][] board) {
    	for (int i = 0; i < 3; i++) {
    		for (int j = 0; j < 3; j++) {
    			for (Node k : buttons) {
    				if (nullConverter(GridPane.getRowIndex(k)) == i && nullConverter(GridPane.getColumnIndex(k)) == j) {
    					Button temp = (Button) k;
    					temp.setText(String.valueOf(board[i][j]));
    					break;
    				}
    			}
    		}
    	}
    }
    
    void updatePlayerTurn(char playerTurn) {
    	turnField.setText(String.valueOf(playerTurn));
    }
    
    void setResult(String result) {
    	playerWin.setText(result);
    }
    
    @FXML
    void save() {
    	
    }
    
    @FXML
    void load() {

    }
}
