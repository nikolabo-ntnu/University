package stateandbehavior;

public class Account {
	double balance = 0;
	double interestRate = 0;
	
	
	void deposit(double amount) {
		if (amount > 0) {
			balance += amount;
		}
	}
	
	void addInterest() {
		balance += balance * (interestRate/100);
	}
	
	double getBalance() {
		return balance;
	}
	
	double getInterestRate() {
		return interestRate;
	}
	
	void setInterestRate(double newInterest) {
		interestRate = newInterest;
	}
	
	public String toString() {
		String result = "Balance: " + getBalance() + "\n"
				+ "Interest rate: " + getInterestRate() + "\n";
		
		return result;
	}
	
	public void print(String title) {
		System.out.println(title + "\n" + toString());
	}
	
	public static void main(String[] args) {
		Account mine = new Account();
		//Start values
		mine.print("Start values:");
		//Showing deposit(100)
		mine.deposit(100);
		mine.print("After deposit(100)");		
		//Showing setInterestRate(5)
		mine.setInterestRate(5);
		mine.print("After setInterestRate(5)");		
		//Showing addInterest()
		mine.addInterest();
		mine.print("After addInterest()");
	}
}
