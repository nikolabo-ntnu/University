package stateandbehavior;
import java.util.ArrayList;

public class StopWatch {
	int totalRuntime = 0;
	
	int startTime, endTime, lapTime;
	
	ArrayList<Integer> laps = new ArrayList<Integer>();
	
	boolean started = false, stopped = false;
	
	// Out //
	
	boolean isStarted() {
		return started;
	}
	
	boolean isStopped() {
		return stopped;
	}
	
	int getTicks() {
		return totalRuntime;
	}
	
	int getTime() {
		if (started && !stopped) { 
			return (totalRuntime - startTime);
		}
		else if (stopped) {
			return (endTime - startTime);
		}
		
		return -1;
	}
	
	int getLapTime() {
		if (started) {
			return (totalRuntime - lapTime);
		}
		
		return -1;
	}
	
	int getLastLapTime() {
		if (laps.size() > 0) {
			return laps.get(laps.size() - 1);
		}
		
		return -1;
	}
	
	// Behaviour //
	
	void tick(int ticks) {
		totalRuntime += ticks;
	}
	
	void start() {
		started = true;
		startTime = lapTime = totalRuntime;
	}
	
	void lap() {
		laps.add(totalRuntime - lapTime);
		lapTime = totalRuntime;
	}
	
	void stop() {
		stopped = true;
		endTime = totalRuntime;
		laps.add(totalRuntime - lapTime);
		lapTime = totalRuntime;
	}
	
	public String toString() {
		String result = "totalRunTime: " + getTicks() + "\n"
						+ "currentRunTime: " + getTime() + "\n"
						+ "started: " + isStarted() + "\n"
						+ "stopped: " + isStopped() + "\n"
						+ "currentLapTime: " + getLapTime() + "\n"
						+ "lastLapTime: " + getLastLapTime() + "\n";
		
		return result;
	}
	
	void print(String title) {
		System.out.println(title + "\n" + toString());
	}
	
	public static void main(String[] args) {
		StopWatch clock = new StopWatch();
		//Showing initial values
		clock.print("Showing initial values");
		//Adding ticks, tick(5)
		clock.tick(5);
		clock.print("Adding ticks, tick(5)");
		//Starting clock, start()
		clock.start();
		clock.print("Starting clock, start()");
		//Adding ticks, tick(5)
		clock.tick(5);
		clock.print("Adding ticks, tick(5)");
		//Adding a lap, lap()
		clock.lap();
		clock.print("Adding a lap, lap()");
		//Adding ticks, tick(7)
		clock.tick(7);
		clock.print("Adding ticks, tick(7)");
		//Stopping clock, stop()
		clock.stop();
		clock.print("Stopping clock, stop()");
	}
}
