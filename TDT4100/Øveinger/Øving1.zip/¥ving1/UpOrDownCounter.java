package stateandbehavior;

public class UpOrDownCounter {
	
	int end;
	int counter;
	
	public UpOrDownCounter(int start, int end) {
		
		if (start == end) {
			throw new IllegalArgumentException("The start and end values are the same. " + start + " == " + end);
		}
		this.end = end;
		counter = start;
	}
	
	int getCounter() {
		return counter;
	}
	
	boolean count() {
		if (counter > end) {
			counter--;
		}
		else if (counter < end){
			counter++;
		}
		
		return !(counter == end);
	}
	
	public static void main(String[] args) {
		UpOrDownCounter tester = new UpOrDownCounter(0, 10);
		boolean temp = true;
		while(temp) {
			temp = tester.count();
			System.out.println(tester.getCounter());
		}
	}
	
}
