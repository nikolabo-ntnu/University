package encapsulation;
import java.util.Date;
import java.util.List;


public class Person {
	
	private String fullName;
	private Date birthdate;
	private String eMail;
	private char gender;
	
	// Change State //
	
	void setName(String name) {
		if (Person.validateName(name, 2)) {
			fullName = name;
		}
	}
	
	void setBirthday(Date birthday) {
		if (Person.validateDate(birthday)) {
			birthdate = birthday;
		}
	}
	
	void setEmail(String eMail) {
		if (Person.validateEmail(eMail, fullName)) {
			this.eMail = eMail;
		}
	}
	
	void setGender(char gender) {
		if (Person.validateGender(gender)) {
			this.gender = gender;
		}
	}
	
	// Out //
	
	String getName() {
		return fullName;
	}
	
	Date getBirthday() {
		return birthdate;
	}
	
	String getEmail() {
		return eMail;
	}
	
	char getGender() {
		return gender;
	}
	
	// Validation //
	
	public static boolean validateName(String name, int expected) {
		String[] nameList = name.split(" ");
		if (nameList.length != expected) {
			throw new IllegalArgumentException("Illegal naming scheme");
		}
		for (String n : nameList) {
			if (!n.matches("(?i)\\b[A-Z]{2,}\\b")) {
				throw new IllegalArgumentException("Illegal naming scheme, " + n);
			}
		}
	
		return true;
	}
	
	public static boolean validateDate(Date birthdate) {
		Date today = new Date();
		if (today.compareTo(birthdate) <= 0) {
			throw new IllegalArgumentException("Date not valid, " + birthdate);
		}
		
		return true;
	}
	
	public static boolean validateEmail(String mail, String fullName) {
		boolean check = false;
		if (mail != null) {
			String name = String.join("." , fullName.split(" ")).toLowerCase();
			if (mail.indexOf("@") > -1) {
				String temp = mail.substring(0, mail.indexOf("@")).toLowerCase();
				if (name.matches(temp)) {
					List<String> code = List.of("ad", "ae", "af", "ag", "ai", "al", "am", "ao", "aq", "ar", "as", "at", "au", "aw", "ax", "az", "ba", "bb", "bd", "be", "bf", "bg", "bh", "bi", "bj", "bl", "bm", "bn", "bo", "bq", "br", "bs", "bt", "bv", "bw", "by", "bz", "ca", "cc", "cd", "cf", "cg", "ch", "ci", "ck", "cl", "cm", "cn", "co", "cr", "cu", "cv", "cw", "cx", "cy", "cz", "de", "dj", "dk", "dm", "do", "dz", "ec", "ee", "eg", "eh", "er", "es", "et", "fi", "fj", "fk", "fm", "fo", "fr", "ga", "gb", "gd", "ge", "gf", "gg", "gh", "gi", "gl", "gm", "gn", "gp", "gq", "gr", "gs", "gt", "gu", "gw", "gy", "hk", "hm", "hn", "hr", "ht", "hu", "id", "ie", "il", "im", "in", "io", "iq", "ir", "is", "it", "je", "jm", "jo", "jp", "ke", "kg", "kh", "ki", "km", "kn", "kp", "kr", "kw", "ky", "kz", "la", "lb", "lc", "li", "lk", "lr", "ls", "lt", "lu", "lv", "ly", "ma", "mc", "md", "me", "mf", "mg", "mh", "mk", "ml", "mm", "mn", "mo", "mp", "mq", "mr", "ms", "mt", "mu", "mv", "mw", "mx", "my", "mz", "na", "nc", "ne", "nf", "ng", "ni", "nl", "no", "np", "nr", "nu", "nz", "om", "pa", "pe", "pf", "pg", "ph", "pk", "pl", "pm", "pn", "pr", "ps", "pt", "pw", "py", "qa", "re", "ro", "rs", "ru", "rw", "sa", "sb", "sc", "sd", "se", "sg", "sh", "si", "sj", "sk", "sl", "sm", "sn", "so", "sr", "ss", "st", "sv", "sx", "sy", "sz", "tc", "td", "tf", "tg", "th", "tj", "tk", "tl", "tm", "tn", "to", "tr", "tt", "tv", "tw", "tz", "ua", "ug", "um", "us", "uy", "uz", "va", "vc", "ve", "vg", "vi", "vn", "vu", "wf", "ws", "ye", "yt", "za", "zm", "zw");
					if (code.contains(mail.substring(mail.lastIndexOf(".") + 1))) {
						check = true;
					}
				}
			}
			if (!check) {
				throw new IllegalArgumentException("Email is not valid");
			}
		}
		
		return true;
	}
	
	public static boolean validateGender(char gend) {
		if (gend != 'M' && gend != 'F' && gend != '\0') {
			throw new IllegalArgumentException("Invalid gender");
		}
		
		return true;
	}
	
	public static void main(String[] args) {
		Person test = new Person();
		test.setName("Ina Miss");
		test.setEmail("ina.miss@gmail.no");
	}
}
