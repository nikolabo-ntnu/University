<?xml version="1.0" encoding="UTF-8"?>
<xmi:XMI xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:exercise="platform:/plugin/no.hal.learning.exercise.model/model/exercise.ecore" xmlns:jdt="platform:/plugin/no.hal.learning.exercise.jdt/model/jdt-exercise.ecore" xmlns:junit="platform:/plugin/no.hal.learning.exercise.junit/model/junit-exercise.ecore" xmlns:workbench="platform:/plugin/no.hal.learning.exercise.workbench/model/workbench-exercise.ecore">
  <exercise:Exercise>
    <parts xsi:type="exercise:ExercisePart" title="Vehicle">
      <tasks xsi:type="exercise:Task">
        <q xsi:type="exercise:StringQuestion" question="Write source code for the Vehicle class."/>
        <a xsi:type="jdt:JdtSourceEditAnswer" className="encapsulation.Vehicle"/>
      </tasks>
      <tasks xsi:type="exercise:Task">
        <q xsi:type="exercise:StringQuestion" question="Run the Vehicle class, to test it."/>
        <a xsi:type="jdt:JdtLaunchAnswer" className="encapsulation.Vehicle"/>
      </tasks>
      <tasks xsi:type="exercise:Task">
        <q xsi:type="exercise:StringQuestion" question="Test the Vehicle class, by running the VehicleTest JUnit test."/>
        <a xsi:type="junit:JunitTestAnswer" testRunName="encapsulation.VehicleTest"/>
      </tasks>
    </parts>
    <parts xsi:type="exercise:ExercisePart" title="Using Eclipse">
      <tasks xsi:type="exercise:Task">
        <q xsi:type="exercise:StringQuestion" question="Use breakpoints to debug code."/>
        <a xsi:type="workbench:DebugEventAnswer" action="suspend.breakpoint"/>
      </tasks>
      <tasks xsi:type="exercise:Task">
        <q xsi:type="exercise:StringQuestion" question="Use the debug command Step Over"/>
        <a xsi:type="workbench:CommandExecutionAnswer" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
      </tasks>
      <tasks xsi:type="exercise:Task">
        <q xsi:type="exercise:StringQuestion" question="Use the debug command Step Into"/>
        <a xsi:type="workbench:CommandExecutionAnswer" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
      </tasks>
      <tasks xsi:type="exercise:Task">
        <q xsi:type="exercise:StringQuestion" question="Use the Variables view"/>
        <a xsi:type="workbench:PartTaskAnswer" elementId="org.eclipse.debug.ui.VariableView" action="activated"/>
      </tasks>
    </parts>
  </exercise:Exercise>
  <exercise:ExerciseProposals exercise="/0">
    <proposals exercisePart="/0/@parts.0">
      <proposals xsi:type="jdt:JdtSourceEditProposal" question="/0/@parts.0/@tasks.0/@q" answer="/0/@parts.0/@tasks.0/@a">
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579520412988" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="38" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:StringEdit" storedString="package encapsulation;&#xA;&#xA;public class Vehicle {&#xA;&#x9;&#xA;&#x9;private char vehicleType;&#xA;&#x9;private char fuelType;&#xA;&#x9;private String registrationNumber;&#xA;&#x9;&#xA;&#x9;public Vehicle(char vType, char fType, String regnum) {&#xA;&#x9;&#x9;validateRegistrationNumber(regnum);&#xA;&#x9;&#x9;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;&#xA;&#x9;// Out //&#xA;&#x9;char getFuelType() {&#xA;&#x9;&#x9;return fuelType;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;char getVehicleType() {&#xA;&#x9;&#x9;return vehicleType;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;String getRegistrationNumber() {&#xA;&#x9;&#x9;return registrationNumber;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;// Misc //&#xA;&#x9;&#xA;&#x9;private void validateRegistrationNumber(String regnum) {&#xA;&#x9;&#x9;boolean result = true;&#xA;&#x9;&#x9;if (!result) {&#xA;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;}&#xA;&#x9;}&#xA;}&#xA;&#xA;&#x9;&#xA;"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579520591284" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="44" errorCount="1" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="vehicleType = vType;&#xA;&#x9;&#x9;fuelType = fType;&#xA;&#x9;&#x9;registrationNumber = regnum;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;&#xA;&#x9;// Out //&#xA;&#x9;char getFuelType() {&#xA;&#x9;&#x9;return fuelType;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;char getVehicleType() {&#xA;&#x9;&#x9;return vehicleType;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;String getRegistrationNumber() {&#xA;&#x9;&#x9;return registrationNumber;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;// Misc //&#xA;&#x9;&#xA;&#x9;private void validateRegistrationNumber(String regnum) {&#xA;&#x9;&#x9;boolean result = false;&#xA;&#x9;&#x9;if (!result) {&#xA;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;}&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;public static void main(String[] args) {&#xA;&#x9;&#x9;Vehicle myCar = new Vehicle(&quot;M&quot;, &quot;E&quot;, &quot;Somenum&quot;);" edit="/1/@proposals.0/@proposals.0/@attempts.0/@edit" start="235" end="-10"/>
          <markers xsi:type="jdt:JdtMarkerInfo" lineNumber="40" charStart="795" charEnd="827" severity="2" problemCategory="50" problemType="134217858"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579520676410" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="45" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="'M', 'E', &quot;Somenum&quot;);&#xA;&#x9;&#x9;System.out.println(myCar.getRegistrationNumber()" edit="/1/@proposals.0/@proposals.0/@attempts.1/@edit" start="768" end="-12"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579520716201" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="45" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="tru" edit="/1/@proposals.0/@proposals.0/@attempts.2/@edit" start="582" end="-266"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579522097767" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="68" warningCount="2" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="import java.util.ArrayList;&#xA;&#xA;public class Vehicle {&#xA;&#x9;&#xA;&#x9;private char vehicleType;&#xA;&#x9;private char fuelType;&#xA;&#x9;private String registrationNumber;&#xA;&#x9;&#xA;&#x9;public Vehicle(char vType, char fType, String regnum) {&#xA;&#x9;&#x9;vehicleType = vType;&#xA;&#x9;&#x9;fuelType = fType;&#xA;&#x9;&#x9;validateRegistrationNumber(regnum);&#xA;&#x9;&#x9;registrationNumber = regnum;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;&#xA;&#x9;// Out //&#xA;&#x9;char getFuelType() {&#xA;&#x9;&#x9;return fuelType;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;char getVehicleType() {&#xA;&#x9;&#x9;return vehicleType;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;String getRegistrationNumber() {&#xA;&#x9;&#x9;return registrationNumber;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;// Misc //&#xA;&#x9;&#xA;&#x9;private void validateRegistrationNumber(String regnum) {&#xA;&#x9;&#x9;boolean valid = true;&#xA;&#x9;&#x9;String start = regnum.substring(0,2);&#xA;&#x9;&#x9;ArrayList&lt;String> electric = new ArrayList&lt;String>() {{&#xA;&#x9;&#x9;&#x9;add(&quot;EL&quot;);&#xA;&#x9;&#x9;&#x9;add(&quot;EK&quot;);&#xA;&#x9;&#x9;}};&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;if (fuelType == 'E') {&#xA;&#x9;&#x9;&#x9;if (!electric.contains(start)) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;else if (fuelType == 'H') {&#xA;&#x9;&#x9;&#x9;if (start != &quot;HY&quot;) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;else {&#xA;&#x9;&#x9;&#x9;if (start == &quot;HY&quot; || electric.contains(start)) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;if (start.matches(&quot;.ÆØÅ&quot;)){&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;public static void main(String[] args) {&#xA;&#x9;&#x9;Vehicle myCar = new Vehicle('M', 'B', &quot;ÆS1002" edit="/1/@proposals.0/@proposals.0/@attempts.3/@edit" start="23" end="-66"/>
          <markers xsi:type="jdt:JdtMarkerInfo" lineNumber="34" charStart="634" charEnd="639" severity="1" problemCategory="120" problemType="536870973"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579522147323" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="68" warningCount="2" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="*[ÆØÅ].*" edit="/1/@proposals.0/@proposals.0/@attempts.4/@edit" start="1221" end="-256"/>
          <markers xsi:type="jdt:JdtMarkerInfo" lineNumber="36" charStart="725" charEnd="744" severity="1" problemCategory="90" problemType="536871008"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579522156611" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="68" warningCount="2" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="&quot;" edit="/1/@proposals.0/@proposals.0/@attempts.5/@edit" start="1227" end="-255"/>
          <markers xsi:type="jdt:JdtMarkerInfo" lineNumber="36" charStart="725" charEnd="744" severity="1" problemCategory="90" problemType="536871008"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579522270654" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="68" warningCount="2" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="contains(&quot;Æ&quot;) || start.contains(&quot;Ø&quot;) || start.contains(&quot;Å" edit="/1/@proposals.0/@proposals.0/@attempts.6/@edit" start="1211" end="-256"/>
          <markers xsi:type="jdt:JdtMarkerInfo" lineNumber="36" charStart="725" charEnd="744" severity="1" problemCategory="90" problemType="536871008"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579522437582" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="80" warningCount="2" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="String end = regnum.substring(2);&#xA;&#x9;&#x9;ArrayList&lt;String> electric = new ArrayList&lt;String>() {{&#xA;&#x9;&#x9;&#x9;add(&quot;EL&quot;);&#xA;&#x9;&#x9;&#x9;add(&quot;EK&quot;);&#xA;&#x9;&#x9;}};&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;if (fuelType == 'E') {&#xA;&#x9;&#x9;&#x9;if (!electric.contains(start)) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;else if (fuelType == 'H') {&#xA;&#x9;&#x9;&#x9;if (start != &quot;HY&quot;) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;else {&#xA;&#x9;&#x9;&#x9;if (start == &quot;HY&quot; || electric.contains(start)) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;if (start.contains(&quot;Æ&quot;) || start.contains(&quot;Ø&quot;) || start.contains(&quot;Å&quot;)){&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;if (vehicleType == 'C') {&#xA;&#x9;&#x9;&#x9;if (end.length() != 5) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;else {&#xA;&#x9;&#x9;&#x9;if (end.length() != 4) " edit="/1/@proposals.0/@proposals.0/@attempts.7/@edit" start="657" end="-253"/>
          <markers xsi:type="jdt:JdtMarkerInfo" lineNumber="37" charStart="762" charEnd="781" severity="1" problemCategory="90" problemType="536871008"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579522849789" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="79" warningCount="1" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="String start = regnum.substring(0,2);&#xA;&#x9;&#x9;String end = regnum.substring(2);&#xA;&#x9;&#x9;ArrayList&lt;String> electric = new ArrayList&lt;String>() {{&#xA;&#x9;&#x9;&#x9;add(&quot;EL&quot;);&#xA;&#x9;&#x9;&#x9;add(&quot;EK&quot;);&#xA;&#x9;&#x9;}};&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;//Assuming correct vehical typing and fuel typing inputed&#xA;&#x9;&#x9;if (fuelType == 'E') {&#xA;&#x9;&#x9;&#x9;if (!electric.contains(start)) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;else if (fuelType == 'H') {&#xA;&#x9;&#x9;&#x9;if (start != &quot;HY&quot;) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;else {&#xA;&#x9;&#x9;&#x9;if (start == &quot;HY&quot; || electric.contains(start)) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;if (start.contains(&quot;Æ&quot;) || start.contains(&quot;Ø&quot;) || start.contains(&quot;Å&quot;)){ // start.matches(&quot;.*[ÆØÅ].*&quot;)" edit="/1/@proposals.0/@proposals.0/@attempts.8/@edit" start="593" end="-530"/>
          <markers xsi:type="jdt:JdtMarkerInfo" lineNumber="36" charStart="737" charEnd="756" severity="1" problemCategory="90" problemType="536871008"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579523050803" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="77" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="s;&#xA;import java.util.List;&#xA;&#xA;public class Vehicle {&#xA;&#x9;&#xA;&#x9;private char vehicleType;&#xA;&#x9;private char fuelType;&#xA;&#x9;private String registrationNumber;&#xA;&#x9;&#xA;&#x9;public Vehicle(char vType, char fType, String regnum) {&#xA;&#x9;&#x9;vehicleType = vType;&#xA;&#x9;&#x9;fuelType = fType;&#xA;&#x9;&#x9;validateRegistrationNumber(regnum);&#xA;&#x9;&#x9;registrationNumber = regnum;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;&#xA;&#x9;// Out //&#xA;&#x9;char getFuelType() {&#xA;&#x9;&#x9;return fuelType;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;char getVehicleType() {&#xA;&#x9;&#x9;return vehicleType;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;String getRegistrationNumber() {&#xA;&#x9;&#x9;return registrationNumber;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;// Misc //&#xA;&#x9;&#xA;&#x9;private void validateRegistrationNumber(String regnum) {&#xA;&#x9;&#x9;String start = regnum.substring(0,2);&#xA;&#x9;&#x9;String end = regnum.substring(2);&#xA;&#x9;&#x9;List&lt;String> electric = Arrays.asList(new String[]{&quot;EL&quot;, &quot;EK&quot;})" edit="/1/@proposals.0/@proposals.0/@attempts.9/@edit" start="45" end="-1144"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579523332054" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="88" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="alidateInput(vType, fType, regnum);&#xA;&#x9;&#x9;vehicleType = vType;&#xA;&#x9;&#x9;fuelType = fType;&#xA;&#x9;&#x9;registrationNumber = regnum;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;&#xA;&#x9;// Out //&#xA;&#x9;char getFuelType() {&#xA;&#x9;&#x9;return fuelType;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;char getVehicleType() {&#xA;&#x9;&#x9;return vehicleType;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;String getRegistrationNumber() {&#xA;&#x9;&#x9;return registrationNumber;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;// Misc //&#xA;&#x9;&#xA;&#x9;private void validateInput(char vType, char fType, String regnum) {&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;List&lt;Character> vTypes = Arrays.asList(new Character[] {'C', 'M'});&#xA;&#x9;&#x9;if (!vTypes.contains(vType)) {&#xA;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg kjøretøystype, &quot; + vType);&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;List&lt;Character> fTypes = Arrays.asList(new Character[] {'H', 'E', 'D', 'G'});&#xA;&#x9;&#x9;if (!fTypes.contains(vType)) {&#xA;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg drivstoffstype, &quot; + fType);&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;//RegistationNumber check&#xA;&#x9;&#x9;String start = regnum.substring(0,2);&#xA;&#x9;&#x9;String end = regnum.substring(2);&#xA;&#x9;&#x9;List&lt;String> electric = Arrays.asList(new String[]{&quot;EL&quot;, &quot;EK&quot;});&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;if (fType == 'E') {&#xA;&#x9;&#x9;&#x9;if (!electric.contains(start)) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;else if (fType == 'H') {&#xA;&#x9;&#x9;&#x9;if (start != &quot;HY&quot;) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;else {&#xA;&#x9;&#x9;&#x9;if (start == &quot;HY&quot; || electric.contains(start)) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;if (start.contains(&quot;Æ&quot;) || start.contains(&quot;Ø&quot;) || start.contains(&quot;Å&quot;)){ // start.matches(&quot;.*[ÆØÅ].*&quot;)&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;if (v" edit="/1/@proposals.0/@proposals.0/@attempts.10/@edit" start="246" end="-422"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579523358183" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="90" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="//vehicalType check&#xA;&#x9;&#x9;List&lt;Character> vTypes = Arrays.asList(new Character[] {'C', 'M'});&#xA;&#x9;&#x9;if (!vTypes.contains(vType)) {&#xA;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg kjøretøystype, &quot; + vType);&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;//fuelType check" edit="/1/@proposals.0/@proposals.0/@attempts.11/@edit" start="628" end="-1437"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579523432302" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="90" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="f" edit="/1/@proposals.0/@proposals.0/@attempts.12/@edit" start="954" end="-1332"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579523720995" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="96" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="&#xA;&#x9;&#x9;for (int i = 0; i &lt; end.length(); i++) {&#xA;&#x9;&#x9;&#x9;if (!Character.isDigit(end.charAt(i))) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;" edit="/1/@proposals.0/@proposals.0/@attempts.13/@edit" start="1860" end="-427"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579523865875" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="102" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="for (char i : start.toCharArray()) {&#xA;&#x9;&#x9;&#x9;if (Character.isLowerCase(i)) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;" edit="/1/@proposals.0/@proposals.0/@attempts.14/@edit" start="1116" end="-1352"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579523904906" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="102" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString=" || Character.isDigit(i)" edit="/1/@proposals.0/@proposals.0/@attempts.15/@edit" start="1184" end="-1452"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579523998762" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="103" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="System.out.println(start);&#xA;&#x9;&#x9;&#x9;" edit="/1/@proposals.0/@proposals.0/@attempts.16/@edit" start="1715" end="-945"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579524177232" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="102" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="for (int i = 0; i &lt; end.length(); i++) {&#xA;&#x9;&#x9;&#x9;if (!Character.isDigit(end.charAt(i))) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;List&lt;String> electric = Arrays.asList(new String[]{&quot;EL&quot;, &quot;EK&quot;});&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;if (fType == 'E') {&#xA;&#x9;&#x9;&#x9;if (!electric.contains(start)) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;else if (fType == 'H') {&#xA;&#x9;&#x9;&#x9;if (start != &quot;HY&quot;) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;else {&#xA;&#x9;&#x9;&#x9;if (start == &quot;HY&quot; || electric.contains(start)) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;if (start.contains(&quot;Æ&quot;) || start.contains(&quot;Ø&quot;) || start.contains(&quot;Å&quot;)){ // start.matches(&quot;.*[ÆØÅ].*&quot;)&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;if (vType == 'C') {&#xA;&#x9;&#x9;&#x9;if (end.length() != 5) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;else {&#xA;&#x9;&#x9;&#x9;if (end.length() != 4) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;public static void main(String[] args) {&#xA;&#x9;&#x9;Vehicle myCar = new Vehicle('C', 'G', &quot;HY12345" edit="/1/@proposals.0/@proposals.0/@attempts.17/@edit" start="1344" end="-66"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579524343977" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="102" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="H" edit="/1/@proposals.0/@proposals.0/@attempts.18/@edit" start="2583" end="-77"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579524396633" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="103" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="System.out.println(start + &quot; HY&quot;);&#xA;&#x9;&#x9;&#x9;&#x9;" edit="/1/@proposals.0/@proposals.0/@attempts.19/@edit" start="1797" end="-864"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579524421476" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="103" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" edit="/1/@proposals.0/@proposals.0/@attempts.20/@edit" start="2699"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579524445786" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="103" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="E', &quot;EL" edit="/1/@proposals.0/@proposals.0/@attempts.21/@edit" start="2622" end="-71"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579524648836" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="103" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="prefix = Arrays.asList(new String[]{&quot;EL&quot;, &quot;EK&quot;, &quot;HY&quot;});&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;if (fType == 'E') {&#xA;&#x9;&#x9;&#x9;if (!prefix.subList(0, 2).contains(start)) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;else if (fType == 'H') {&#xA;&#x9;&#x9;&#x9;if (start != prefix.get(2)) {&#xA;&#x9;&#x9;&#x9;&#x9;System.out.println(start + &quot; HY&quot;);&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;else {&#xA;&#x9;&#x9;&#x9;if (start == prefix.get(2) || prefix.contains(start)) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;if (start.contains(&quot;Æ&quot;) || start.contains(&quot;Ø&quot;) || start.contains(&quot;Å&quot;)){ // start.matches(&quot;.*[ÆØÅ].*&quot;)&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;if (vType == 'C') {&#xA;&#x9;&#x9;&#x9;if (end.length() != 5) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;else {&#xA;&#x9;&#x9;&#x9;if (end.length() != 4) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;public static void main(String[] args) {&#xA;&#x9;&#x9;Vehicle myCar = new Vehicle('C', 'H', &quot;HY" edit="/1/@proposals.0/@proposals.0/@attempts.22/@edit" start="1538" end="-71"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579524805734" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="103" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="!=" edit="/1/@proposals.0/@proposals.0/@attempts.23/@edit" start="1850" end="-882"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579524822745" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="103" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString=" " edit="/1/@proposals.0/@proposals.0/@attempts.24/@edit" start="1850" end="-884"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579524927440" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="103" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="!start.equals(prefix.get(2))) {&#xA;&#x9;&#x9;&#x9;&#x9;System.out.println(start + &quot; != HY&quot;);&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;else {&#xA;&#x9;&#x9;&#x9;if (start.equals(prefix.get(2)" edit="/1/@proposals.0/@proposals.0/@attempts.25/@edit" start="1792" end="-747"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579524934381" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="102" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="t" edit="/1/@proposals.0/@proposals.0/@attempts.26/@edit" start="1828" end="-875"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579525130436" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="105" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="if (vType == 'M' &amp;&amp; fType == 'H') {&#xA;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Bare biler kan gå på hydrogen!&quot;);&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;" edit="/1/@proposals.0/@proposals.0/@attempts.27/@edit" start="1045" end="-1659"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579525992011" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="110" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="&#xA;&#x9;void setRegistrationNumber(String regnum) {&#xA;&#x9;&#x9;validateInput(vehicleType, fuelType, regnum);&#xA;&#x9;&#x9;registrationNumber = regnum;&#xA;&#x9;}&#xA;&#x9;// " edit="/1/@proposals.0/@proposals.0/@attempts.28/@edit" start="544" end="-2275"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579612762268" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="111" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="switch (fType) {&#xA;&#x9;&#x9;&#x9;case ('E'):&#xA;&#x9;&#x9;&#x9;&#x9;if (!prefix.subList(0, 2).contains(start)) {&#xA;&#x9;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;&#x9;break;&#xA;&#x9;&#x9;&#x9;case ('H'):&#xA;&#x9;&#x9;&#x9;&#x9;if (!start.equals(prefix.get(2))) {&#xA;&#x9;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;&#x9;break;&#xA;&#x9;&#x9;&#x9;default:&#xA;&#x9;&#x9;&#x9;&#x9;if (start.equals(prefix.get(2)) || prefix.contains(start)) {&#xA;&#x9;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;&#x9;if (start.matches(&quot;.*[ÆØÅ].*&quot;)){&#xA;&#x9;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;&#x9;}&#xA;&#x9;" edit="/1/@proposals.0/@proposals.0/@attempts.29/@edit" start="1846" end="-437"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579612915252" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="110" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="if (vType != 'C' &amp;&amp; vType != 'M') {&#xA;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg kjøretøystype, &quot; + vType);&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;//fuelType check&#xA;&#x9;&#x9;List&lt;Character> fTypes = Arrays.asList(new Character[] {'H', 'E', 'D', 'G'});&#xA;&#x9;&#x9;if (!fTypes.contains(fType)) {&#xA;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg drivstoffstype, &quot; + fType);&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;if (vType != 'C" edit="/1/@proposals.0/@proposals.0/@attempts.30/@edit" start="782" end="-1720"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579613217082" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="114" errorCount="7" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="List;&#xA;&#xA;public class Vehicle {&#xA;&#x9;&#xA;&#x9;private char vehicleType;&#xA;&#x9;private char fuelType;&#xA;&#x9;private String registrationNumber;&#xA;&#x9;&#xA;&#x9;public Vehicle(char vType, char fType, String regnum) {&#xA;&#x9;&#x9;validateInput(vType, fType, regnum);&#xA;&#x9;&#x9;vehicleType = vType;&#xA;&#x9;&#x9;fuelType = fType;&#xA;&#x9;&#x9;registrationNumber = regnum;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;&#xA;&#x9;// Out //&#xA;&#x9;char getFuelType() {&#xA;&#x9;&#x9;return fuelType;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;char getVehicleType() {&#xA;&#x9;&#x9;return vehicleType;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;String getRegistrationNumber() {&#xA;&#x9;&#x9;return registrationNumber;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;// &#xA;&#x9;void setRegistrationNumber(String regnum) {&#xA;&#x9;&#x9;validateInput(vehicleType, fuelType, regnum);&#xA;&#x9;&#x9;registrationNumber = regnum;&#xA;&#x9;}&#xA;&#x9;// Misc //&#xA;&#x9;&#xA;&#x9;private void validateInput(char vType, char fType, String regnum) {&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;//vehicalType check&#xA;&#x9;&#x9;if (vType != 'C' &amp;&amp; vType != 'M') {&#xA;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg kjøretøystype, &quot; + vType);&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;//fuelType check&#xA;&#x9;&#x9;ArrayList&lt;Character> fTypes = new ArrayList&lt;Character>() {{&#xA;&#x9;&#x9;&#x9;add('H');&#xA;&#x9;&#x9;&#x9;add('E');&#xA;&#x9;&#x9;&#x9;add('D');&#xA;&#x9;&#x9;&#x9;add('G');&#xA;&#x9;&#x9;}}" edit="/1/@proposals.0/@proposals.0/@attempts.31/@edit" start="40" end="-1851"/>
          <markers xsi:type="jdt:JdtMarkerInfo" lineNumber="74" charStart="1817" charEnd="1823" severity="2" problemCategory="50" problemType="570425394"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579613279603" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="109" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="List&lt;Character> fTypes = List.of('H', 'E', 'D', 'G');&#xA;&#x9;&#x9;if (!fTypes.contains(fType)) {&#xA;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg drivstoffstype, &quot; + fType);&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;if (vType != 'C' &amp;&amp; fType == 'H') {&#xA;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Bare biler kan gå på hydrogen!&quot;);&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;//RegistationNumber check&#xA;&#x9;&#x9;String start = regnum.substring(0,2);&#xA;&#x9;&#x9;for (char i : start.toCharArray()) {&#xA;&#x9;&#x9;&#x9;if (Character.isLowerCase(i) || Character.isDigit(i)) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;String end = regnum.substring(2);&#xA;&#x9;&#x9;for (int i = 0; i &lt; end.length(); i++) {&#xA;&#x9;&#x9;&#x9;if (!Character.isDigit(end.charAt(i))) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;List&lt;String> prefix = List.of(&quot;EL&quot;, &quot;EK&quot;, &quot;HY&quot;" edit="/1/@proposals.0/@proposals.0/@attempts.32/@edit" start="895" end="-1074"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579613686481" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="120" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="import java.util.regex.Pattern;&#xA;&#xA;public class Vehicle {&#xA;&#x9;&#xA;&#x9;private char vehicleType;&#xA;&#x9;private char fuelType;&#xA;&#x9;private String registrationNumber;&#xA;&#x9;&#xA;&#x9;public Vehicle(char vType, char fType, String regnum) {&#xA;&#x9;&#x9;validateInput(vType, fType, regnum);&#xA;&#x9;&#x9;vehicleType = vType;&#xA;&#x9;&#x9;fuelType = fType;&#xA;&#x9;&#x9;registrationNumber = regnum;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;&#xA;&#x9;// Out //&#xA;&#x9;char getFuelType() {&#xA;&#x9;&#x9;return fuelType;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;char getVehicleType() {&#xA;&#x9;&#x9;return vehicleType;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;String getRegistrationNumber() {&#xA;&#x9;&#x9;return registrationNumber;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;// &#xA;&#x9;void setRegistrationNumber(String regnum) {&#xA;&#x9;&#x9;validateInput(vehicleType, fuelType, regnum);&#xA;&#x9;&#x9;registrationNumber = regnum;&#xA;&#x9;}&#xA;&#x9;// Misc //&#xA;&#x9;&#xA;&#x9;private void validateInput(char vType, char fType, String regnum) {&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;//vehicalType check&#xA;&#x9;&#x9;if (vType != 'C' &amp;&amp; vType != 'M') {&#xA;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg kjøretøystype, &quot; + vType);&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;//fuelType check&#xA;&#x9;&#x9;List&lt;Character> fTypes = List.of('H', 'E', 'D', 'G');&#xA;&#x9;&#x9;if (!fTypes.contains(fType)) {&#xA;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg drivstoffstype, &quot; + fType);&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;if (vType != 'C' &amp;&amp; fType == 'H') {&#xA;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Bare biler kan gå på hydrogen!&quot;);&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;if (vType == 'C') {&#xA;&#x9;&#x9;&#x9;if (!Pattern.matches(&quot;[A-Z]{2}[0-9]{5}&quot;, regnum)) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;else {&#xA;&#x9;&#x9;&#x9;if (!Pattern.matches(&quot;[A-Z]{2}[0-9]{4}&quot;, regnum)) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;/*&#xA;&#x9;&#x9;//RegistationNumber check&#xA;&#x9;&#x9;String start = regnum.substring(0,2);&#xA;&#x9;&#x9;for (char i : start.toCharArray()) {&#xA;&#x9;&#x9;&#x9;if (Character.isLowerCase(i) || Character.isDigit(i)) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;String end = regnum.substring(2);&#xA;&#x9;&#x9;for (int i = 0; i &lt; end.length(); i++) {&#xA;&#x9;&#x9;&#x9;if (!Character.isDigit(end.charAt(i))) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;if (vType == 'C') {&#xA;&#x9;&#x9;&#x9;if (end.length() != 5) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;else {&#xA;&#x9;&#x9;&#x9;if (end.length() != 4) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;List&lt;String> prefix = List.of(&quot;EL&quot;, &quot;EK&quot;, &quot;HY&quot;);&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;switch (fType) {&#xA;&#x9;&#x9;&#x9;case ('E'):&#xA;&#x9;&#x9;&#x9;&#x9;if (!prefix.subList(0, 2).contains(start)) {&#xA;&#x9;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;&#x9;break;&#xA;&#x9;&#x9;&#x9;case ('H'):&#xA;&#x9;&#x9;&#x9;&#x9;if (!start.equals(prefix.get(2))) {&#xA;&#x9;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;&#x9;break;&#xA;&#x9;&#x9;&#x9;default:&#xA;&#x9;&#x9;&#x9;&#x9;if (start.equals(prefix.get(2)) || prefix.contains(start)) {&#xA;&#x9;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;&#x9;if (start.matches(&quot;.*[ÆØÅ].*&quot;)){&#xA;&#x9;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;*/" edit="/1/@proposals.0/@proposals.0/@attempts.33/@edit" start="46" end="-162"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579614496292" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="144" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="&#xA;&#x9;&#x9;boolean error = false;&#xA;&#x9;&#x9;if (vType == 'C') {&#xA;&#x9;&#x9;&#x9;if (!Pattern.matches(&quot;[A-Z]{2}[0-9]{5}&quot;, regnum)) {&#xA;&#x9;&#x9;&#x9;&#x9;error = true;&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;else {&#xA;&#x9;&#x9;&#x9;if (!Pattern.matches(&quot;[A-Z]{2}[0-9]{4}&quot;, regnum)) {&#xA;&#x9;&#x9;&#x9;&#x9;error = true;&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;if (!error) {&#xA;&#x9;&#x9;&#x9;switch(fType) {&#xA;&#x9;&#x9;&#x9;case('H'):&#xA;&#x9;&#x9;&#x9;&#x9;if (!regnum.substring(0,2).equals(&quot;HY&quot;)) {&#xA;&#x9;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;break;&#xA;&#x9;&#x9;&#x9;case('E'):&#xA;&#x9;&#x9;&#x9;&#x9;if (!List.of(&quot;EL&quot;, &quot;EK&quot;).contains(regnum.substring(0,2))) {&#xA;&#x9;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;&#x9;break;&#xA;&#x9;&#x9;&#x9;default:&#xA;&#x9;&#x9;&#x9;&#x9;if (List.of(&quot;EL&quot;, &quot;EK&quot;).contains(regnum.substring(0,2)) || regnum.substring(0,2).equals(&quot;HY&quot;)) {&#xA;&#x9;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;else {&#xA;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);" edit="/1/@proposals.0/@proposals.0/@attempts.34/@edit" start="1210" end="-1611"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579614792258" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="149" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="if (Vehicle.validateInput(vType, fType, regnum)) {&#xA;&#x9;&#x9;&#x9;vehicleType = vType;&#xA;&#x9;&#x9;&#x9;fuelType = fType;&#xA;&#x9;&#x9;&#x9;registrationNumber = regnum;&#xA;&#x9;&#x9;}&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;&#xA;&#x9;// Out //&#xA;&#x9;char getFuelType() {&#xA;&#x9;&#x9;return fuelType;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;char getVehicleType() {&#xA;&#x9;&#x9;return vehicleType;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;String getRegistrationNumber() {&#xA;&#x9;&#x9;return registrationNumber;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;// Change state //&#xA;&#x9;&#xA;&#x9;void setRegistrationNumber(String regnum) {&#xA;&#x9;&#x9;if (Vehicle.validateInput(vehicleType, fuelType, regnum)) {&#xA;&#x9;&#x9;&#x9;registrationNumber = regnum;&#xA;&#x9;&#x9;}&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;// Misc //&#xA;&#x9;&#xA;&#x9;public static boolean validateInput(char vType, char fType, String regnum) {&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;//vehicalType check&#xA;&#x9;&#x9;if (vType != 'C' &amp;&amp; vType != 'M') {&#xA;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg kjøretøystype, &quot; + vType);&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;//fuelType check&#xA;&#x9;&#x9;List&lt;Character> fTypes = List.of('H', 'E', 'D', 'G');&#xA;&#x9;&#x9;if (!fTypes.contains(fType)) {&#xA;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg drivstoffstype, &quot; + fType);&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;if (vType != 'C' &amp;&amp; fType == 'H') {&#xA;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Bare biler kan gå på hydrogen!&quot;);&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;boolean error = false;&#xA;&#x9;&#x9;if (vType == 'C') {&#xA;&#x9;&#x9;&#x9;if (!Pattern.matches(&quot;[A-Z]{2}[0-9]{5}&quot;, regnum)) {&#xA;&#x9;&#x9;&#x9;&#x9;error = true;&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;else {&#xA;&#x9;&#x9;&#x9;if (!Pattern.matches(&quot;[A-Z]{2}[0-9]{4}&quot;, regnum)) {&#xA;&#x9;&#x9;&#x9;&#x9;error = true;&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;if (!error) {&#xA;&#x9;&#x9;&#x9;switch(fType) {&#xA;&#x9;&#x9;&#x9;case('H'):&#xA;&#x9;&#x9;&#x9;&#x9;if (!regnum.substring(0,2).equals(&quot;HY&quot;)) {&#xA;&#x9;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;break;&#xA;&#x9;&#x9;&#x9;case('E'):&#xA;&#x9;&#x9;&#x9;&#x9;if (!List.of(&quot;EL&quot;, &quot;EK&quot;).contains(regnum.substring(0,2))) {&#xA;&#x9;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;&#x9;break;&#xA;&#x9;&#x9;&#x9;default:&#xA;&#x9;&#x9;&#x9;&#x9;if (List.of(&quot;EL&quot;, &quot;EK&quot;).contains(regnum.substring(0,2)) || regnum.substring(0,2).equals(&quot;HY&quot;)) {&#xA;&#x9;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;else {&#xA;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;/*&#xA;&#x9;&#x9;//RegistationNumber check&#xA;&#x9;&#x9;String start = regnum.substring(0,2);&#xA;&#x9;&#x9;for (char i : start.toCharArray()) {&#xA;&#x9;&#x9;&#x9;if (Character.isLowerCase(i) || Character.isDigit(i)) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;String end = regnum.substring(2);&#xA;&#x9;&#x9;for (int i = 0; i &lt; end.length(); i++) {&#xA;&#x9;&#x9;&#x9;if (!Character.isDigit(end.charAt(i))) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;if (vType == 'C') {&#xA;&#x9;&#x9;&#x9;if (end.length() != 5) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;else {&#xA;&#x9;&#x9;&#x9;if (end.length() != 4) {&#xA;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;List&lt;String> prefix = List.of(&quot;EL&quot;, &quot;EK&quot;, &quot;HY&quot;);&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;switch (fType) {&#xA;&#x9;&#x9;&#x9;case ('E'):&#xA;&#x9;&#x9;&#x9;&#x9;if (!prefix.subList(0, 2).contains(start)) {&#xA;&#x9;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;&#x9;break;&#xA;&#x9;&#x9;&#x9;case ('H'):&#xA;&#x9;&#x9;&#x9;&#x9;if (!start.equals(prefix.get(2))) {&#xA;&#x9;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;&#x9;break;&#xA;&#x9;&#x9;&#x9;default:&#xA;&#x9;&#x9;&#x9;&#x9;if (start.equals(prefix.get(2)) || prefix.contains(start)) {&#xA;&#x9;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;&#x9;if (start.matches(&quot;.*[ÆØÅ].*&quot;)){&#xA;&#x9;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;*/&#xA;&#x9;&#x9;return true;" edit="/1/@proposals.0/@proposals.0/@attempts.35/@edit" start="252" end="-162"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579614891354" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="102" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString=" || vType != 'C') {&#xA;&#x9;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;break;&#xA;&#x9;&#x9;&#x9;case('E'):&#xA;&#x9;&#x9;&#x9;&#x9;if (!List.of(&quot;EL&quot;, &quot;EK&quot;).contains(regnum.substring(0,2))) {&#xA;&#x9;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;&#x9;break;&#xA;&#x9;&#x9;&#x9;default:&#xA;&#x9;&#x9;&#x9;&#x9;if (List.of(&quot;EL&quot;, &quot;EK&quot;).contains(regnum.substring(0,2)) || regnum.substring(0,2).equals(&quot;HY&quot;)) {&#xA;&#x9;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;else {&#xA;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;" edit="/1/@proposals.0/@proposals.0/@attempts.36/@edit" start="1594" end="-177"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579614896790" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="99" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="&#xA;" edit="/1/@proposals.0/@proposals.0/@attempts.37/@edit" start="1163" end="-1096"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579615157675" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="97" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="&#xA;&#x9;private char vehicleType;&#xA;&#x9;private char fuelType;&#xA;&#x9;private String registrationNumber;&#xA;&#xA;&#x9;public Vehicle(char vType, char fType, String regnum) {&#xA;&#x9;&#x9;if (Vehicle.validateInput(vType, fType, regnum)) {&#xA;&#x9;&#x9;&#x9;vehicleType = vType;&#xA;&#x9;&#x9;&#x9;fuelType = fType;&#xA;&#x9;&#x9;&#x9;registrationNumber = regnum;&#xA;&#x9;&#x9;}&#xA;&#x9;}&#xA;&#xA;&#xA;&#x9;// Out //&#xA;&#x9;char getFuelType() {&#xA;&#x9;&#x9;return fuelType;&#xA;&#x9;}&#xA;&#xA;&#x9;char getVehicleType() {&#xA;&#x9;&#x9;return vehicleType;&#xA;&#x9;}&#xA;&#xA;&#x9;String getRegistrationNumber() {&#xA;&#x9;&#x9;return registrationNumber;&#xA;&#x9;}&#xA;&#xA;&#x9;// Change state //&#xA;&#xA;&#x9;void setRegistrationNumber(String regnum) {&#xA;&#x9;&#x9;if (Vehicle.validateInput(vehicleType, fuelType, regnum)) {&#xA;&#x9;&#x9;&#x9;registrationNumber = regnum;&#xA;&#x9;&#x9;}&#xA;&#x9;}&#xA;&#xA;&#x9;// Misc //&#xA;&#xA;&#x9;public static boolean validateInput(char vType, char fType, String regnum) {&#xA;&#x9;&#x9;//vehicalType check&#xA;&#x9;&#x9;if (/*vType != 'C' &amp;&amp; vType != 'M' */ Pattern.matches(&quot;C|M&quot;, Character.toString(vType))) {&#xA;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg kjøretøystype, &quot; + vType);&#xA;&#x9;&#x9;}&#xA;&#xA;&#x9;&#x9;//fuelType check&#xA;&#x9;&#x9;List&lt;Character> fTypes = List.of('H', 'E', 'D', 'G');&#xA;&#x9;&#x9;if (!fTypes.contains(fType)) {&#xA;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg drivstoffstype, &quot; + fType);&#xA;&#x9;&#x9;}&#xA;&#xA;&#x9;&#x9;boolean error = false;&#xA;&#x9;&#x9;if (vType == 'C') {&#xA;&#x9;&#x9;&#x9;if (!Pattern.matches(&quot;[A-Z]{2}[0-9]{5}&quot;, regnum)) {&#xA;&#x9;&#x9;&#x9;&#x9;error = true;&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;else {&#xA;&#x9;&#x9;&#x9;if (!Pattern.matches(&quot;[A-Z]{2}[0-9]{4}&quot;, regnum)) {&#xA;&#x9;&#x9;&#x9;&#x9;error = true;&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#xA;&#x9;&#x9;if (!error) {&#xA;&#x9;&#x9;&#x9;switch(fType) {&#xA;&#x9;&#x9;&#x9;case('H'):&#xA;&#x9;&#x9;&#x9;&#x9;if (!regnum.substring(0,2).equals(&quot;HY&quot;) || vType != 'C') {&#xA;&#x9;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;&#x9;break;&#x9;&#x9;&#xA;&#x9;&#x9;&#x9;case('E'):&#xA;&#x9;&#x9;&#x9;&#x9;if (!List.of(&quot;EL&quot;, &quot;EK&quot;).contains(regnum.substring(0,2))) {&#xA;&#x9;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;&#x9;break;&#xA;&#x9;&#x9;&#x9;default:&#xA;&#x9;&#x9;&#x9;&#x9;if (List.of(&quot;EL&quot;, &quot;EK&quot;).contains(regnum.substring(0,2)) || regnum.substring(0,2).equals(&quot;HY&quot;)) {&#xA;&#x9;&#x9;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;&#x9;}&#xA;&#x9;&#x9;}&#xA;&#x9;&#x9;else {&#xA;&#x9;&#x9;&#x9;throw new IllegalArgumentException(&quot;Ugylidg registreringsnummer, &quot; + regnum);&#xA;&#x9;&#x9;}&#xA;&#xA;&#x9;&#x9;return true;&#xA;&#x9;}&#xA;&#xA;&#x9;public static void main(String[] args) {&#xA;&#x9;&#x9;Vehicle myCar = new Vehicle('C', 'H', &quot;HY12345&quot;);&#xA;&#x9;&#x9;System.out.println(myCar.getRegistrationNumber());&#xA;&#x9;}&#xA;}&#xA;" edit="/1/@proposals.0/@proposals.0/@attempts.38/@edit" start="102" end="-2"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579615241130" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="97" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="!" edit="/1/@proposals.0/@proposals.0/@attempts.39/@edit" start="882" end="-1412"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1579615303435" resourcePath="/ovinger/src/encapsulation/Vehicle.java" sizeMeasure="97" className="encapsulation.Vehicle">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="vType != 'C' &amp;&amp; vType != 'M'" edit="/1/@proposals.0/@proposals.0/@attempts.40/@edit" start="848" end="-1363"/>
        </attempts>
      </proposals>
      <proposals xsi:type="jdt:JdtLaunchProposal" question="/0/@parts.0/@tasks.1/@q" answer="/0/@parts.0/@tasks.1/@a">
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1579520674567" mode="run" className="encapsulation.Vehicle">
          <launchAttrNames>org.eclipse.jdt.launching.CLASSPATH_PROVIDER</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.SOURCE_PATH_PROVIDER</launchAttrNames>
          <launchAttrValues>org.eclipse.m2e.launchconfig.classpathProvider</launchAttrValues>
          <launchAttrValues>encapsulation.Vehicle</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <launchAttrValues>org.eclipse.m2e.launchconfig.sourcepathProvider</launchAttrValues>
          <consoleOutput>Exception in thread &quot;main&quot; java.lang.IllegalArgumentException: Ugylidg registreringsnummer, Somenum&#xD;
	at ovinger/encapsulation.Vehicle.validateRegistrationNumber(Vehicle.java:35)&#xD;
	at ovinger/encapsulation.Vehicle.&lt;init>(Vehicle.java:10)&#xD;
	at ovinger/encapsulation.Vehicle.main(Vehicle.java:40)&#xD;
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1579520717869" mode="run" className="encapsulation.Vehicle">
          <launchAttrNames>org.eclipse.jdt.launching.CLASSPATH_PROVIDER</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.SOURCE_PATH_PROVIDER</launchAttrNames>
          <launchAttrValues>org.eclipse.m2e.launchconfig.classpathProvider</launchAttrValues>
          <launchAttrValues>encapsulation.Vehicle</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <launchAttrValues>org.eclipse.m2e.launchconfig.sourcepathProvider</launchAttrValues>
          <consoleOutput>Somenum&#xD;
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1579522094982" mode="run" className="encapsulation.Vehicle">
          <launchAttrNames>org.eclipse.jdt.launching.CLASSPATH_PROVIDER</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.SOURCE_PATH_PROVIDER</launchAttrNames>
          <launchAttrValues>org.eclipse.m2e.launchconfig.classpathProvider</launchAttrValues>
          <launchAttrValues>encapsulation.Vehicle</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <launchAttrValues>org.eclipse.m2e.launchconfig.sourcepathProvider</launchAttrValues>
          <consoleOutput>ÆS1002&#xD;
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1579522145862" mode="run" className="encapsulation.Vehicle">
          <launchAttrNames>org.eclipse.jdt.launching.CLASSPATH_PROVIDER</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.SOURCE_PATH_PROVIDER</launchAttrNames>
          <launchAttrValues>org.eclipse.m2e.launchconfig.classpathProvider</launchAttrValues>
          <launchAttrValues>encapsulation.Vehicle</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <launchAttrValues>org.eclipse.m2e.launchconfig.sourcepathProvider</launchAttrValues>
          <consoleOutput>Exception in thread &quot;main&quot; java.lang.IllegalArgumentException: Ugylidg registreringsnummer, ÆS1002&#xD;
	at ovinger/encapsulation.Vehicle.validateRegistrationNumber(Vehicle.java:57)&#xD;
	at ovinger/encapsulation.Vehicle.&lt;init>(Vehicle.java:13)&#xD;
	at ovinger/encapsulation.Vehicle.main(Vehicle.java:63)&#xD;
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1579522159197" mode="run" className="encapsulation.Vehicle">
          <launchAttrNames>org.eclipse.jdt.launching.CLASSPATH_PROVIDER</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.SOURCE_PATH_PROVIDER</launchAttrNames>
          <launchAttrValues>org.eclipse.m2e.launchconfig.classpathProvider</launchAttrValues>
          <launchAttrValues>encapsulation.Vehicle</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <launchAttrValues>org.eclipse.m2e.launchconfig.sourcepathProvider</launchAttrValues>
          <consoleOutput>ÆS1002&#xD;
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1579522273409" mode="run" className="encapsulation.Vehicle">
          <launchAttrNames>org.eclipse.jdt.launching.CLASSPATH_PROVIDER</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.SOURCE_PATH_PROVIDER</launchAttrNames>
          <launchAttrValues>org.eclipse.m2e.launchconfig.classpathProvider</launchAttrValues>
          <launchAttrValues>encapsulation.Vehicle</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <launchAttrValues>org.eclipse.m2e.launchconfig.sourcepathProvider</launchAttrValues>
          <consoleOutput>Exception in thread &quot;main&quot; java.lang.IllegalArgumentException: Ugylidg registreringsnummer, ÆS1002&#xD;
	at ovinger/encapsulation.Vehicle.validateRegistrationNumber(Vehicle.java:57)&#xD;
	at ovinger/encapsulation.Vehicle.&lt;init>(Vehicle.java:13)&#xD;
	at ovinger/encapsulation.Vehicle.main(Vehicle.java:63)&#xD;
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1579523048451" mode="run" className="encapsulation.Vehicle">
          <launchAttrNames>org.eclipse.jdt.launching.CLASSPATH_PROVIDER</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.SOURCE_PATH_PROVIDER</launchAttrNames>
          <launchAttrValues>org.eclipse.m2e.launchconfig.classpathProvider</launchAttrValues>
          <launchAttrValues>encapsulation.Vehicle</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <launchAttrValues>org.eclipse.m2e.launchconfig.sourcepathProvider</launchAttrValues>
          <consoleOutput>Exception in thread &quot;main&quot; java.lang.IllegalArgumentException: Ugylidg registreringsnummer, ÆS1002&#xD;
	at ovinger/encapsulation.Vehicle.validateRegistrationNumber(Vehicle.java:55)&#xD;
	at ovinger/encapsulation.Vehicle.&lt;init>(Vehicle.java:14)&#xD;
	at ovinger/encapsulation.Vehicle.main(Vehicle.java:72)&#xD;
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1579523359989" mode="run" className="encapsulation.Vehicle">
          <launchAttrNames>org.eclipse.jdt.launching.CLASSPATH_PROVIDER</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.SOURCE_PATH_PROVIDER</launchAttrNames>
          <launchAttrValues>org.eclipse.m2e.launchconfig.classpathProvider</launchAttrValues>
          <launchAttrValues>encapsulation.Vehicle</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <launchAttrValues>org.eclipse.m2e.launchconfig.sourcepathProvider</launchAttrValues>
          <consoleOutput>Exception in thread &quot;main&quot; java.lang.IllegalArgumentException: Ugylidg drivstoffstype, B&#xD;
	at ovinger/encapsulation.Vehicle.validateInput(Vehicle.java:45)&#xD;
	at ovinger/encapsulation.Vehicle.&lt;init>(Vehicle.java:12)&#xD;
	at ovinger/encapsulation.Vehicle.main(Vehicle.java:85)&#xD;
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1579524179086" mode="run" className="encapsulation.Vehicle">
          <launchAttrNames>org.eclipse.jdt.launching.CLASSPATH_PROVIDER</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.SOURCE_PATH_PROVIDER</launchAttrNames>
          <launchAttrValues>org.eclipse.m2e.launchconfig.classpathProvider</launchAttrValues>
          <launchAttrValues>encapsulation.Vehicle</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <launchAttrValues>org.eclipse.m2e.launchconfig.sourcepathProvider</launchAttrValues>
          <consoleOutput>HY12345&#xD;
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1579524205614" mode="debug" className="encapsulation.Vehicle">
          <launchAttrNames>org.eclipse.jdt.launching.CLASSPATH_PROVIDER</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.SOURCE_PATH_PROVIDER</launchAttrNames>
          <launchAttrValues>org.eclipse.m2e.launchconfig.classpathProvider</launchAttrValues>
          <launchAttrValues>encapsulation.Vehicle</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <launchAttrValues>org.eclipse.m2e.launchconfig.sourcepathProvider</launchAttrValues>
          <consoleOutput>HY12345&#xD;
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1579524241925" mode="debug" className="encapsulation.Vehicle">
          <launchAttrNames>org.eclipse.jdt.launching.CLASSPATH_PROVIDER</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.SOURCE_PATH_PROVIDER</launchAttrNames>
          <launchAttrValues>org.eclipse.m2e.launchconfig.classpathProvider</launchAttrValues>
          <launchAttrValues>encapsulation.Vehicle</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <launchAttrValues>org.eclipse.m2e.launchconfig.sourcepathProvider</launchAttrValues>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1579524319152" mode="run" className="encapsulation.Vehicle">
          <launchAttrNames>org.eclipse.jdt.launching.CLASSPATH_PROVIDER</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.SOURCE_PATH_PROVIDER</launchAttrNames>
          <launchAttrValues>org.eclipse.m2e.launchconfig.classpathProvider</launchAttrValues>
          <launchAttrValues>encapsulation.Vehicle</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <launchAttrValues>org.eclipse.m2e.launchconfig.sourcepathProvider</launchAttrValues>
          <consoleOutput>HY12345&#xD;
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1579524341203" mode="debug" className="encapsulation.Vehicle">
          <launchAttrNames>org.eclipse.jdt.launching.CLASSPATH_PROVIDER</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.SOURCE_PATH_PROVIDER</launchAttrNames>
          <launchAttrValues>org.eclipse.m2e.launchconfig.classpathProvider</launchAttrValues>
          <launchAttrValues>encapsulation.Vehicle</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <launchAttrValues>org.eclipse.m2e.launchconfig.sourcepathProvider</launchAttrValues>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1579524352099" mode="debug" className="encapsulation.Vehicle">
          <launchAttrNames>org.eclipse.jdt.launching.CLASSPATH_PROVIDER</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.SOURCE_PATH_PROVIDER</launchAttrNames>
          <launchAttrValues>org.eclipse.m2e.launchconfig.classpathProvider</launchAttrValues>
          <launchAttrValues>encapsulation.Vehicle</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <launchAttrValues>org.eclipse.m2e.launchconfig.sourcepathProvider</launchAttrValues>
          <consoleOutput>Exception in thread &quot;main&quot; java.lang.IllegalArgumentException: Ugylidg registreringsnummer, HY12345&#xD;
	at ovinger/encapsulation.Vehicle.validateInput(Vehicle.java:72)&#xD;
	at ovinger/encapsulation.Vehicle.&lt;init>(Vehicle.java:12)&#xD;
	at ovinger/encapsulation.Vehicle.main(Vehicle.java:97)&#xD;
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1579524401867" mode="run" className="encapsulation.Vehicle">
          <launchAttrNames>org.eclipse.jdt.launching.CLASSPATH_PROVIDER</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.SOURCE_PATH_PROVIDER</launchAttrNames>
          <launchAttrValues>org.eclipse.m2e.launchconfig.classpathProvider</launchAttrValues>
          <launchAttrValues>encapsulation.Vehicle</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <launchAttrValues>org.eclipse.m2e.launchconfig.sourcepathProvider</launchAttrValues>
          <consoleOutput>HY HY&#xD;
Exception in thread &quot;main&quot; java.lang.IllegalArgumentException: Ugylidg registreringsnummer, HY12345&#xD;
	at ovinger/encapsulation.Vehicle.validateInput(Vehicle.java:73)&#xD;
	at ovinger/encapsulation.Vehicle.&lt;init>(Vehicle.java:12)&#xD;
	at ovinger/encapsulation.Vehicle.main(Vehicle.java:98)&#xD;
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1579524418684" mode="run" className="encapsulation.Vehicle">
          <launchAttrNames>org.eclipse.jdt.launching.CLASSPATH_PROVIDER</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.SOURCE_PATH_PROVIDER</launchAttrNames>
          <launchAttrValues>org.eclipse.m2e.launchconfig.classpathProvider</launchAttrValues>
          <launchAttrValues>encapsulation.Vehicle</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <launchAttrValues>org.eclipse.m2e.launchconfig.sourcepathProvider</launchAttrValues>
          <consoleOutput>HY HY&#xD;
Exception in thread &quot;main&quot; java.lang.IllegalArgumentException: Ugylidg registreringsnummer, HY12345&#xD;
	at ovinger/encapsulation.Vehicle.validateInput(Vehicle.java:73)&#xD;
	at ovinger/encapsulation.Vehicle.&lt;init>(Vehicle.java:12)&#xD;
	at ovinger/encapsulation.Vehicle.main(Vehicle.java:98)&#xD;
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1579524446744" mode="run" className="encapsulation.Vehicle">
          <launchAttrNames>org.eclipse.jdt.launching.CLASSPATH_PROVIDER</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.SOURCE_PATH_PROVIDER</launchAttrNames>
          <launchAttrValues>org.eclipse.m2e.launchconfig.classpathProvider</launchAttrValues>
          <launchAttrValues>encapsulation.Vehicle</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <launchAttrValues>org.eclipse.m2e.launchconfig.sourcepathProvider</launchAttrValues>
          <consoleOutput>EL12345&#xD;
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1579524649797" mode="debug" className="encapsulation.Vehicle">
          <launchAttrNames>org.eclipse.jdt.launching.CLASSPATH_PROVIDER</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.SOURCE_PATH_PROVIDER</launchAttrNames>
          <launchAttrValues>org.eclipse.m2e.launchconfig.classpathProvider</launchAttrValues>
          <launchAttrValues>encapsulation.Vehicle</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <launchAttrValues>org.eclipse.m2e.launchconfig.sourcepathProvider</launchAttrValues>
          <consoleOutput>HY HY&#xD;
</consoleOutput>
          <consoleOutput>Exception in thread &quot;main&quot; java.lang.IllegalArgumentException: Ugylidg registreringsnummer, HY12345&#xD;
	at ovinger/encapsulation.Vehicle.validateInput(Vehicle.java:73)&#xD;
	at ovinger/encapsulation.Vehicle.&lt;init>(Vehicle.java:12)&#xD;
	at ovinger/encapsulation.Vehicle.main(Vehicle.java:98)&#xD;
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1579524698153" mode="debug" className="encapsulation.Vehicle">
          <launchAttrNames>org.eclipse.jdt.launching.CLASSPATH_PROVIDER</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.SOURCE_PATH_PROVIDER</launchAttrNames>
          <launchAttrValues>org.eclipse.m2e.launchconfig.classpathProvider</launchAttrValues>
          <launchAttrValues>encapsulation.Vehicle</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <launchAttrValues>org.eclipse.m2e.launchconfig.sourcepathProvider</launchAttrValues>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1579524804394" mode="run" className="encapsulation.Vehicle">
          <launchAttrNames>org.eclipse.jdt.launching.CLASSPATH_PROVIDER</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.SOURCE_PATH_PROVIDER</launchAttrNames>
          <launchAttrValues>org.eclipse.m2e.launchconfig.classpathProvider</launchAttrValues>
          <launchAttrValues>encapsulation.Vehicle</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <launchAttrValues>org.eclipse.m2e.launchconfig.sourcepathProvider</launchAttrValues>
          <consoleOutput>HY!= HY&#xD;
Exception in thread &quot;main&quot; java.lang.IllegalArgumentException: Ugylidg registreringsnummer, HY12345&#xD;
	at ovinger/encapsulation.Vehicle.validateInput(Vehicle.java:73)&#xD;
	at ovinger/encapsulation.Vehicle.&lt;init>(Vehicle.java:12)&#xD;
	at ovinger/encapsulation.Vehicle.main(Vehicle.java:98)&#xD;
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1579524820541" mode="run" className="encapsulation.Vehicle">
          <launchAttrNames>org.eclipse.jdt.launching.CLASSPATH_PROVIDER</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.SOURCE_PATH_PROVIDER</launchAttrNames>
          <launchAttrValues>org.eclipse.m2e.launchconfig.classpathProvider</launchAttrValues>
          <launchAttrValues>encapsulation.Vehicle</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <launchAttrValues>org.eclipse.m2e.launchconfig.sourcepathProvider</launchAttrValues>
          <consoleOutput>HY != HY&#xD;
Exception in thread &quot;main&quot; java.lang.IllegalArgumentException: Ugylidg registreringsnummer, HY12345&#xD;
	at ovinger/encapsulation.Vehicle.validateInput(Vehicle.java:73)&#xD;
	at ovinger/encapsulation.Vehicle.&lt;init>(Vehicle.java:12)&#xD;
	at ovinger/encapsulation.Vehicle.main(Vehicle.java:98)&#xD;
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1579524925216" mode="run" className="encapsulation.Vehicle">
          <launchAttrNames>org.eclipse.jdt.launching.CLASSPATH_PROVIDER</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.SOURCE_PATH_PROVIDER</launchAttrNames>
          <launchAttrValues>org.eclipse.m2e.launchconfig.classpathProvider</launchAttrValues>
          <launchAttrValues>encapsulation.Vehicle</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <launchAttrValues>org.eclipse.m2e.launchconfig.sourcepathProvider</launchAttrValues>
          <consoleOutput>HY12345&#xD;
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1579524937030" mode="debug" className="encapsulation.Vehicle">
          <launchAttrNames>org.eclipse.jdt.launching.CLASSPATH_PROVIDER</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.SOURCE_PATH_PROVIDER</launchAttrNames>
          <launchAttrValues>org.eclipse.m2e.launchconfig.classpathProvider</launchAttrValues>
          <launchAttrValues>encapsulation.Vehicle</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <launchAttrValues>org.eclipse.m2e.launchconfig.sourcepathProvider</launchAttrValues>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1579525142086" mode="run" className="encapsulation.Vehicle">
          <launchAttrNames>org.eclipse.jdt.launching.CLASSPATH_PROVIDER</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.SOURCE_PATH_PROVIDER</launchAttrNames>
          <launchAttrValues>org.eclipse.m2e.launchconfig.classpathProvider</launchAttrValues>
          <launchAttrValues>encapsulation.Vehicle</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <launchAttrValues>org.eclipse.m2e.launchconfig.sourcepathProvider</launchAttrValues>
          <consoleOutput>HY12345&#xD;
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1579526002571" mode="run" className="encapsulation.Vehicle">
          <launchAttrNames>org.eclipse.jdt.launching.CLASSPATH_PROVIDER</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.SOURCE_PATH_PROVIDER</launchAttrNames>
          <launchAttrValues>org.eclipse.m2e.launchconfig.classpathProvider</launchAttrValues>
          <launchAttrValues>encapsulation.Vehicle</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <launchAttrValues>org.eclipse.m2e.launchconfig.sourcepathProvider</launchAttrValues>
          <consoleOutput>HY12345&#xD;
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1579526009075" mode="run" className="encapsulation.Vehicle">
          <launchAttrNames>org.eclipse.jdt.launching.CLASSPATH_PROVIDER</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.SOURCE_PATH_PROVIDER</launchAttrNames>
          <launchAttrValues>org.eclipse.m2e.launchconfig.classpathProvider</launchAttrValues>
          <launchAttrValues>encapsulation.Vehicle</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <launchAttrValues>org.eclipse.m2e.launchconfig.sourcepathProvider</launchAttrValues>
          <consoleOutput>HY12345&#xD;
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1579525995292" mode="debug" className="encapsulation.Vehicle">
          <launchAttrNames>org.eclipse.jdt.launching.CLASSPATH_PROVIDER</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.SOURCE_PATH_PROVIDER</launchAttrNames>
          <launchAttrValues>org.eclipse.m2e.launchconfig.classpathProvider</launchAttrValues>
          <launchAttrValues>encapsulation.Vehicle</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <launchAttrValues>org.eclipse.m2e.launchconfig.sourcepathProvider</launchAttrValues>
        </attempts>
      </proposals>
      <proposals xsi:type="junit:JunitTestProposal" question="/0/@parts.0/@tasks.2/@q" answer="/0/@parts.0/@tasks.2/@a">
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1579522861054" completion="0.2857142857142857" testRunName="encapsulation.VehicleTest" successCount="2" failureCount="2" errorCount="3">
          <successTests>testConstructorCorrectUse</successTests>
          <successTests>testConstructorInvalidVehicleType</successTests>
          <failureTests>testConstructorInvalidFuel</failureTests>
          <failureTests>testConstructorInvalidRegistrationNumber</failureTests>
          <errorTests>testSetRegistrationNumberInvalidUse</errorTests>
          <errorTests>testSetRegistrationNumberInvalidUseDoesntChangeState</errorTests>
          <errorTests>testSetRegistrationNumberCorrectUse</errorTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1579523369191" completion="0.42857142857142855" testRunName="encapsulation.VehicleTest" successCount="3" errorCount="4">
          <successTests>testConstructorInvalidFuel</successTests>
          <successTests>testConstructorInvalidRegistrationNumber</successTests>
          <successTests>testConstructorInvalidVehicleType</successTests>
          <errorTests>testSetRegistrationNumberInvalidUse</errorTests>
          <errorTests>testConstructorCorrectUse</errorTests>
          <errorTests>testSetRegistrationNumberInvalidUseDoesntChangeState</errorTests>
          <errorTests>testSetRegistrationNumberCorrectUse</errorTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1579523436078" completion="0.42857142857142855" testRunName="encapsulation.VehicleTest" successCount="3" failureCount="1" errorCount="3">
          <successTests>testConstructorInvalidFuel</successTests>
          <successTests>testConstructorCorrectUse</successTests>
          <successTests>testConstructorInvalidVehicleType</successTests>
          <failureTests>testConstructorInvalidRegistrationNumber</failureTests>
          <errorTests>testSetRegistrationNumberInvalidUse</errorTests>
          <errorTests>testSetRegistrationNumberInvalidUseDoesntChangeState</errorTests>
          <errorTests>testSetRegistrationNumberCorrectUse</errorTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1579523727115" completion="0.42857142857142855" testRunName="encapsulation.VehicleTest" successCount="3" failureCount="1" errorCount="3">
          <successTests>testConstructorInvalidFuel</successTests>
          <successTests>testConstructorCorrectUse</successTests>
          <successTests>testConstructorInvalidVehicleType</successTests>
          <failureTests>testConstructorInvalidRegistrationNumber</failureTests>
          <errorTests>testSetRegistrationNumberInvalidUse</errorTests>
          <errorTests>testSetRegistrationNumberInvalidUseDoesntChangeState</errorTests>
          <errorTests>testSetRegistrationNumberCorrectUse</errorTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1579523871119" completion="0.42857142857142855" testRunName="encapsulation.VehicleTest" successCount="3" failureCount="1" errorCount="3">
          <successTests>testConstructorInvalidFuel</successTests>
          <successTests>testConstructorCorrectUse</successTests>
          <successTests>testConstructorInvalidVehicleType</successTests>
          <failureTests>testConstructorInvalidRegistrationNumber</failureTests>
          <errorTests>testSetRegistrationNumberInvalidUse</errorTests>
          <errorTests>testSetRegistrationNumberInvalidUseDoesntChangeState</errorTests>
          <errorTests>testSetRegistrationNumberCorrectUse</errorTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1579523908714" completion="0.42857142857142855" testRunName="encapsulation.VehicleTest" successCount="3" failureCount="1" errorCount="3">
          <successTests>testConstructorInvalidFuel</successTests>
          <successTests>testConstructorCorrectUse</successTests>
          <successTests>testConstructorInvalidVehicleType</successTests>
          <failureTests>testConstructorInvalidRegistrationNumber</failureTests>
          <errorTests>testSetRegistrationNumberInvalidUse</errorTests>
          <errorTests>testSetRegistrationNumberInvalidUseDoesntChangeState</errorTests>
          <errorTests>testSetRegistrationNumberCorrectUse</errorTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1579524002317" completion="0.42857142857142855" testRunName="encapsulation.VehicleTest" successCount="3" failureCount="1" errorCount="3">
          <successTests>testConstructorInvalidFuel</successTests>
          <successTests>testConstructorCorrectUse</successTests>
          <successTests>testConstructorInvalidVehicleType</successTests>
          <failureTests>testConstructorInvalidRegistrationNumber</failureTests>
          <errorTests>testSetRegistrationNumberInvalidUse</errorTests>
          <errorTests>testSetRegistrationNumberInvalidUseDoesntChangeState</errorTests>
          <errorTests>testSetRegistrationNumberCorrectUse</errorTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1579524947120" completion="0.42857142857142855" testRunName="encapsulation.VehicleTest" successCount="3" failureCount="1" errorCount="3">
          <successTests>testConstructorInvalidRegistrationNumber</successTests>
          <successTests>testConstructorCorrectUse</successTests>
          <successTests>testConstructorInvalidVehicleType</successTests>
          <failureTests>testConstructorInvalidFuel</failureTests>
          <errorTests>testSetRegistrationNumberInvalidUse</errorTests>
          <errorTests>testSetRegistrationNumberInvalidUseDoesntChangeState</errorTests>
          <errorTests>testSetRegistrationNumberCorrectUse</errorTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1579525150244" completion="0.5714285714285714" testRunName="encapsulation.VehicleTest" successCount="4" errorCount="3">
          <successTests>testConstructorInvalidFuel</successTests>
          <successTests>testConstructorInvalidRegistrationNumber</successTests>
          <successTests>testConstructorCorrectUse</successTests>
          <successTests>testConstructorInvalidVehicleType</successTests>
          <errorTests>testSetRegistrationNumberInvalidUse</errorTests>
          <errorTests>testSetRegistrationNumberInvalidUseDoesntChangeState</errorTests>
          <errorTests>testSetRegistrationNumberCorrectUse</errorTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1579526044876" completion="1.0" testRunName="encapsulation.VehicleTest" successCount="7">
          <successTests>testConstructorInvalidFuel</successTests>
          <successTests>testConstructorInvalidRegistrationNumber</successTests>
          <successTests>testSetRegistrationNumberInvalidUse</successTests>
          <successTests>testConstructorCorrectUse</successTests>
          <successTests>testConstructorInvalidVehicleType</successTests>
          <successTests>testSetRegistrationNumberInvalidUseDoesntChangeState</successTests>
          <successTests>testSetRegistrationNumberCorrectUse</successTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1579613305611" completion="1.0" testRunName="encapsulation.VehicleTest" successCount="7">
          <successTests>testConstructorInvalidFuel</successTests>
          <successTests>testConstructorInvalidRegistrationNumber</successTests>
          <successTests>testSetRegistrationNumberInvalidUse</successTests>
          <successTests>testConstructorCorrectUse</successTests>
          <successTests>testConstructorInvalidVehicleType</successTests>
          <successTests>testSetRegistrationNumberInvalidUseDoesntChangeState</successTests>
          <successTests>testSetRegistrationNumberCorrectUse</successTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1579613692991" completion="0.5714285714285714" testRunName="encapsulation.VehicleTest" successCount="4" failureCount="3">
          <successTests>testConstructorInvalidFuel</successTests>
          <successTests>testConstructorCorrectUse</successTests>
          <successTests>testConstructorInvalidVehicleType</successTests>
          <successTests>testSetRegistrationNumberCorrectUse</successTests>
          <failureTests>testConstructorInvalidRegistrationNumber</failureTests>
          <failureTests>testSetRegistrationNumberInvalidUse</failureTests>
          <failureTests>testSetRegistrationNumberInvalidUseDoesntChangeState</failureTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1579614501492" completion="1.0" testRunName="encapsulation.VehicleTest" successCount="7">
          <successTests>testConstructorInvalidFuel</successTests>
          <successTests>testConstructorInvalidRegistrationNumber</successTests>
          <successTests>testSetRegistrationNumberInvalidUse</successTests>
          <successTests>testConstructorCorrectUse</successTests>
          <successTests>testConstructorInvalidVehicleType</successTests>
          <successTests>testSetRegistrationNumberInvalidUseDoesntChangeState</successTests>
          <successTests>testSetRegistrationNumberCorrectUse</successTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1579614797303" completion="1.0" testRunName="encapsulation.VehicleTest" successCount="7">
          <successTests>testConstructorInvalidFuel</successTests>
          <successTests>testConstructorInvalidRegistrationNumber</successTests>
          <successTests>testSetRegistrationNumberInvalidUse</successTests>
          <successTests>testConstructorCorrectUse</successTests>
          <successTests>testConstructorInvalidVehicleType</successTests>
          <successTests>testSetRegistrationNumberInvalidUseDoesntChangeState</successTests>
          <successTests>testSetRegistrationNumberCorrectUse</successTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1579614902702" completion="1.0" testRunName="encapsulation.VehicleTest" successCount="7">
          <successTests>testConstructorInvalidFuel</successTests>
          <successTests>testConstructorInvalidRegistrationNumber</successTests>
          <successTests>testSetRegistrationNumberInvalidUse</successTests>
          <successTests>testConstructorCorrectUse</successTests>
          <successTests>testConstructorInvalidVehicleType</successTests>
          <successTests>testSetRegistrationNumberInvalidUseDoesntChangeState</successTests>
          <successTests>testSetRegistrationNumberCorrectUse</successTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1579615164852" completion="0.42857142857142855" testRunName="encapsulation.VehicleTest" successCount="3" errorCount="4">
          <successTests>testConstructorInvalidFuel</successTests>
          <successTests>testConstructorInvalidRegistrationNumber</successTests>
          <successTests>testConstructorInvalidVehicleType</successTests>
          <errorTests>testSetRegistrationNumberInvalidUse</errorTests>
          <errorTests>testConstructorCorrectUse</errorTests>
          <errorTests>testSetRegistrationNumberInvalidUseDoesntChangeState</errorTests>
          <errorTests>testSetRegistrationNumberCorrectUse</errorTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1579615245388" completion="1.0" testRunName="encapsulation.VehicleTest" successCount="7">
          <successTests>testConstructorInvalidFuel</successTests>
          <successTests>testConstructorInvalidRegistrationNumber</successTests>
          <successTests>testSetRegistrationNumberInvalidUse</successTests>
          <successTests>testConstructorCorrectUse</successTests>
          <successTests>testConstructorInvalidVehicleType</successTests>
          <successTests>testSetRegistrationNumberInvalidUseDoesntChangeState</successTests>
          <successTests>testSetRegistrationNumberCorrectUse</successTests>
        </attempts>
      </proposals>
    </proposals>
    <proposals exercisePart="/0/@parts.1">
      <proposals xsi:type="workbench:DebugEventProposal" question="/0/@parts.1/@tasks.0/@q" answer="/0/@parts.1/@tasks.0/@a">
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579524208118" elementId="encapsulation.Vehicle" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579524244495" elementId="encapsulation.Vehicle" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579524283081" elementId="encapsulation.Vehicle" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579524346890" elementId="encapsulation.Vehicle" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579524354837" elementId="encapsulation.Vehicle" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579524362691" elementId="encapsulation.Vehicle" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579524364523" elementId="encapsulation.Vehicle" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579524366708" elementId="encapsulation.Vehicle" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579524652248" elementId="encapsulation.Vehicle" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579524660614" elementId="encapsulation.Vehicle" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579524671644" elementId="encapsulation.Vehicle" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579524672585" elementId="encapsulation.Vehicle" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579524700679" elementId="encapsulation.Vehicle" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579524940530" elementId="encapsulation.Vehicle" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579525999878" elementId="encapsulation.Vehicle" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579625621969" elementId="encapsulation.Person" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579625644837" elementId="encapsulation.Person" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579625673879" elementId="encapsulation.Person" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579625704614" elementId="encapsulation.Person" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579625713718" elementId="encapsulation.Person" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579625728983" elementId="encapsulation.Person" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579625769254" elementId="encapsulation.Person" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579625787802" elementId="encapsulation.Person" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579625791810" elementId="encapsulation.Person" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579625822137" elementId="encapsulation.Person" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579625824352" elementId="encapsulation.Person" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579625901233" elementId="encapsulation.Person" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579625911726" elementId="encapsulation.Person" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579625914364" elementId="encapsulation.Person" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579625923971" elementId="encapsulation.Person" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579625951179" elementId="encapsulation.Person" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579625954819" elementId="encapsulation.Person" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579626035365" elementId="encapsulation.Person" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579626055373" elementId="encapsulation.Person" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579626060015" elementId="encapsulation.Person" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579626063137" elementId="encapsulation.Person" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579626065957" elementId="encapsulation.Person" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579626086573" elementId="encapsulation.Person" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579626087614" elementId="encapsulation.Person" action="suspend.breakpoint"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1579626093948" elementId="encapsulation.Person" action="suspend.breakpoint"/>
      </proposals>
      <proposals xsi:type="workbench:CommandExecutionProposal" question="/0/@parts.1/@tasks.1/@q" answer="/0/@parts.1/@tasks.1/@a"/>
      <proposals xsi:type="workbench:CommandExecutionProposal" question="/0/@parts.1/@tasks.2/@q" answer="/0/@parts.1/@tasks.2/@a"/>
      <proposals xsi:type="workbench:PartTaskProposal" question="/0/@parts.1/@tasks.3/@q" answer="/0/@parts.1/@tasks.3/@a">
        <attempts xsi:type="workbench:PartTaskEvent" timestamp="1579518316520" elementId="org.eclipse.debug.ui.VariableView" action="activated"/>
        <attempts xsi:type="workbench:PartTaskEvent" timestamp="1579518364028" elementId="org.eclipse.debug.ui.VariableView" action="activated"/>
        <attempts xsi:type="workbench:PartTaskEvent" timestamp="1579520710164" elementId="org.eclipse.debug.ui.VariableView" action="activated"/>
        <attempts xsi:type="workbench:PartTaskEvent" timestamp="1579524300507" elementId="org.eclipse.debug.ui.VariableView" action="activated"/>
        <attempts xsi:type="workbench:PartTaskEvent" timestamp="1579524665173" elementId="org.eclipse.debug.ui.VariableView" action="activated"/>
        <attempts xsi:type="workbench:PartTaskEvent" timestamp="1579524715667" elementId="org.eclipse.debug.ui.VariableView" action="activated"/>
        <attempts xsi:type="workbench:PartTaskEvent" timestamp="1579625774368" elementId="org.eclipse.debug.ui.VariableView" action="activated"/>
        <attempts xsi:type="workbench:PartTaskEvent" timestamp="1579625962064" elementId="org.eclipse.debug.ui.VariableView" action="activated"/>
        <attempts xsi:type="workbench:PartTaskEvent" timestamp="1579626232361" elementId="org.eclipse.debug.ui.VariableView" action="activated"/>
      </proposals>
    </proposals>
  </exercise:ExerciseProposals>
</xmi:XMI>
