package encapsulation;
import java.util.List;
import java.util.regex.Pattern;

public class Vehicle {

	private char vehicleType;
	private char fuelType;
	private String registrationNumber;

	public Vehicle(char vType, char fType, String regnum) {
		if (Vehicle.validateInput(vType, fType, regnum)) {
			vehicleType = vType;
			fuelType = fType;
			registrationNumber = regnum;
		}
	}


	// Out //
	char getFuelType() {
		return fuelType;
	}

	char getVehicleType() {
		return vehicleType;
	}

	String getRegistrationNumber() {
		return registrationNumber;
	}

	// Change state //

	void setRegistrationNumber(String regnum) {
		if (Vehicle.validateInput(vehicleType, fuelType, regnum)) {
			registrationNumber = regnum;
		}
	}

	// Misc //

	public static boolean validateInput(char vType, char fType, String regnum) {
		//vehicalType check
		if (vType != 'C' && vType != 'M') {
			throw new IllegalArgumentException("Ugylidg kj�ret�ystype, " + vType);
		}

		//fuelType check
		List<Character> fTypes = List.of('H', 'E', 'D', 'G');
		if (!fTypes.contains(fType)) {
			throw new IllegalArgumentException("Ugylidg drivstoffstype, " + fType);
		}

		boolean error = false;
		if (vType == 'C') {
			if (!Pattern.matches("[A-Z]{2}[0-9]{5}", regnum)) {
				error = true;
			}
		}
		else {
			if (!Pattern.matches("[A-Z]{2}[0-9]{4}", regnum)) {
				error = true;
			}
		}

		if (!error) {
			switch(fType) {
			case('H'):
				if (!regnum.substring(0,2).equals("HY") || vType != 'C') {
					throw new IllegalArgumentException("Ugylidg registreringsnummer, " + regnum);
				}
				break;		
			case('E'):
				if (!List.of("EL", "EK").contains(regnum.substring(0,2))) {
					throw new IllegalArgumentException("Ugylidg registreringsnummer, " + regnum);
				}
				break;
			default:
				if (List.of("EL", "EK").contains(regnum.substring(0,2)) || regnum.substring(0,2).equals("HY")) {
					throw new IllegalArgumentException("Ugylidg registreringsnummer, " + regnum);
				}
			}
		}
		else {
			throw new IllegalArgumentException("Ugylidg registreringsnummer, " + regnum);
		}

		return true;
	}

	public static void main(String[] args) {
		Vehicle myCar = new Vehicle('C', 'H', "HY12345");
		System.out.println(myCar.getRegistrationNumber());
	}
}

