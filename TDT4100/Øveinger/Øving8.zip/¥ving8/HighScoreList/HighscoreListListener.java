package patterns.observable;

public interface HighscoreListListener {

	public void listChanged(HighscoreList li, int index);
	
}
